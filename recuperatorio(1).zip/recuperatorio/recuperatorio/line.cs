﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace recuperatorio
{
    public class Line
    {
        public int letter { get; set; }
        public string roadType { get; set; }
        public int length { get; set; }
    }
}
