﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace recuperatorio
{
    class Program
    {
        static void Main(string[] args)
        {

            var sw = System.Diagnostics.Stopwatch.StartNew();

            //
            // Process cmd-line args, welcome msg:
            //
            string infile = AppDomain.CurrentDomain.BaseDirectory + @"\..\..\..\vial.csv";
            int maxCapacity = 10000;  // size of collection between producer and consumers:

            //
            // (1) Read infile using a separate task "producer":
            //
            sw.Restart();

            // shared work queue between producer and consumers:
            BlockingCollection<string> workQ = new BlockingCollection<string>(maxCapacity);

            // Note: inform .NET scheduler that tasks are long-running:
            var tf = new TaskFactory(TaskCreationOptions.LongRunning, TaskContinuationOptions.None);

            Task producer = tf.StartNew(() =>
            {
                //
                // Producer simply puts records from file into work queue:
                //
                foreach (string record in File.ReadLines(infile))
                    workQ.Add(record);

                // Signal that we are done adding to the queue:
                workQ.CompleteAdding();
            }
            );


            // 
            // (2) Foreach record, parse and aggregate the pairs <letter, <road type, length>>,
            // using a set of "consumer" tasks, one per core:
            //
            Dictionary<int, Dictionary<String, int>> completeReport = new Dictionary<int, Dictionary<String, int>>();
            long totalLength = 0;

            //
            // We need to keep track of consumers, and each consumer needs a private
            // dictionary for collecting its results.  This private dictionary is 
            // then returned as the result of the task when it completes:
            //
            int numCores = System.Environment.ProcessorCount;

            Task<Dictionary<int, Dictionary<String, int>>>[] consumers = new Task<Dictionary<int, Dictionary<String, int>>>[numCores];

            for (int i = 0; i < numCores; i++)  // 1 consumer per core:
            {

                // each consumer will return a dictionary of its pairs:
                consumers[i] = tf.StartNew<Dictionary<int, Dictionary<String, int>>>(() =>
                {
                    Dictionary<int, Dictionary<String, int>> localD = new Dictionary<int, Dictionary<String, int>>();

                    //
                    // while producer is not completed and queue is not empty:
                    //
                    while (!workQ.IsCompleted)
                    {
                        try
                        {
                            //
                            // wait for a record, throws exception if producer has 
                            // completed and none will become available:
                            //
                            string line = workQ.Take();
                            Line lineObj = parse(line);

                            //if lineObj is equal to null there is something wrong with this line
                            if (lineObj != null)
                            {
                                processLine(localD, lineObj.letter, lineObj.roadType, lineObj.length);
                            }
                            
                        }
                        catch (ObjectDisposedException)
                        {
                            /* ignore -- no record */
                        }
                        catch (InvalidOperationException)
                        {
                            /* ignore --- no record */
                        }
                    }//while

                    //
                    // return our dictionary for main thread to aggregate:
                    //
                    return localD;
                }
                );

            }


            //
            // (3) WaitAllOneByOne:
            //
            // Now wait for the consumers to finish...  As they do, we 
            // aggregate their individual results into global dictionary:
            //
            int completed = 0;

            while (completed < numCores)
            {
                // 
                // wait for one to finish, then grab their result:
                //
                int tid = Task.WaitAny(consumers);

                Dictionary<int, Dictionary<String, int>> localD = consumers[tid].Result;

                //
                // merge into global data structure:
                //
                foreach (int letter in localD.Keys)
                {
                    foreach (String roadType in localD[letter].Keys)
                    {
                        processLine(completeReport, letter, roadType, localD[letter][roadType]);
                    }
                }

                //
                // remove completed task from array and repeat:
                //
                completed++;
                consumers = consumers.Where((t) => t != consumers[tid]).ToArray();
            }//while

            long timems = sw.ElapsedMilliseconds;

            //
            // Write out the results:
            //
            Console.WriteLine();

            foreach (var letter in completeReport)
            {
                foreach (var roadType in completeReport[letter.Key])
                {
                    Console.WriteLine("{0} - {1}: {2}", letter.Key, roadType.Key, roadType.Value);
                    totalLength += roadType.Value;
                }
            }

            Console.WriteLine();
            Console.WriteLine("Largo total de los caminos del país: {0}", totalLength);

            // 
            // Done:
            //
            double time = timems / 1000.0;  // convert milliseconds to secs

            Console.WriteLine();
            Console.WriteLine("** Done! Time: {0:0.000} secs", time);
            Console.WriteLine();
            Console.WriteLine();

            //
            // As per TPL guidelines, wait for producer to finish so we can 
            // check for any exceptions:
            //
            try
            {
                producer.Wait();
            }
            catch (AggregateException ae)
            {
                ae = ae.Flatten();
                foreach (Exception e in ae.InnerExceptions)
                    Console.WriteLine("NOTE: unexpected error from producer: '{0}'.", e.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("NOTE: unexpected error from producer: '{0}'.", ex.Message);
            }

            Console.WriteLine("Presione Enter para finalizar");
            Console.ReadLine();
        }


        /// <summary>
        /// Parses one line of the netflix data file, and returns the userid who reviewed the movie.
        /// </summary>
        /// <param name="line"></param>
        /// <returns></returns>
        private static Line parse(string line)
        {
            char[] separators = { ',' };

            //
            // movie id, user id, rating (1..5), date (YYYY-MM-DD)
            //
            string[] tokens = line.Split(separators);

            //Control columns count
            if (tokens.Length != 5)
            {
                //Incorrect line format
                return null;
            }

            //Parse line
            int letter;
            if (Int32.TryParse(tokens[0], out letter) == false)
            {
                return null;
            }
            String roadType = tokens[3];
            int length;
            if (Int32.TryParse(tokens[4], out length) == false)
            {
                return null;
            }

            //Object instance
            Line lineObj = new Line();
            lineObj.letter = letter;
            lineObj.roadType = roadType;
            lineObj.length = length;

            return lineObj;
        }

        /// <summary>
        /// Process the line info with tls dictionary
        /// </summary>
        /// <param name="tls"></param>
        /// <param name="letter"></param>
        /// <param name="roadType"></param>
        /// <param name="length"></param>
        public static void processLine(Dictionary<int, Dictionary<String, int>> tls, int letter, String roadType, int length)
        {
            Dictionary<String, int> dicAux;
            if (!tls.ContainsKey(letter)) {  // first letter:
                dicAux = new Dictionary<String, int>();
                dicAux.Add(roadType, length);
                tls.Add(letter, dicAux);
            } else
            {  // letter exists, check road type:
                if (!tls[letter].ContainsKey(roadType))
                {  // first road type:
                    tls[letter].Add(roadType, length);
                } else
                { //road type exists
                    tls[letter][roadType] += length;
                }
            }
        }

    }
}
